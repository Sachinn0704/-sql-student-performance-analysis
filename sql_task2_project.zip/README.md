# SQL Data Analysis Internship - Task 2

## 📌 Project Overview
This project extends a Student Management Database by adding:
- Courses Table
- Enrollments Table

It demonstrates SQL concepts like:
- Joins
- Aggregations
- Group By

## 📂 Files Included
- `task2.sql` → Contains schema and queries

## 🚀 How to Run
1. Open MySQL / PostgreSQL / DB Fiddle
2. Run the SQL script
3. Execute queries to see results

## 📊 Queries Implemented
- Students in each course
- Average grade per course
- Top 3 students
- Failed students count

## 📎 Based on Task Description
See assignment details here: SQL Data Analysis Internship – Task 2
