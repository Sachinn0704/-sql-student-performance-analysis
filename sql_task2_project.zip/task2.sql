-- SQL Data Analysis Internship - Task 2

-- Create Courses Table
CREATE TABLE courses (
    id INT PRIMARY KEY,
    name VARCHAR(50)
);

-- Create Enrollments Table
CREATE TABLE enrollments (
    student_id INT,
    course_id INT,
    grade INT,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (course_id) REFERENCES courses(id)
);

-- Query 1: List all students in each course
SELECT s.name, c.name AS course_name
FROM enrollments e
JOIN students s ON e.student_id = s.id
JOIN courses c ON e.course_id = c.id;

-- Query 2: Average grade per course
SELECT c.name, AVG(e.grade) AS avg_grade
FROM enrollments e
JOIN courses c ON e.course_id = c.id
GROUP BY c.name;

-- Query 3: Top 3 students overall
SELECT s.name, AVG(e.grade) AS avg_grade
FROM enrollments e
JOIN students s ON e.student_id = s.id
GROUP BY s.name
ORDER BY avg_grade DESC
LIMIT 3;

-- Query 4: Count students who failed
SELECT COUNT(*) AS failed_students
FROM enrollments
WHERE grade < 40;
